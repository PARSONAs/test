import React from 'react';
import './scss/SectionPublicComponent.scss';
import './scss/Section4Component.scss';

export default function Section4Component(props) {
    return (
        <section id='section4' className='section'>
            <h1>섹션4</h1>
        </section>
    );
}