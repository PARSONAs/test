import React from 'react';
import './scss/SectionPublicComponent.scss';
import './scss/Section3Component.scss';

export default function Section3Component(props) {
    return (
        <section id='section3' className='section'>
            <h1>섹션3</h1>
        </section>
    );
}