import React from 'react';
import './scss/SectionPublicComponent.scss';
import './scss/Section5Component.scss';

export default function Section5Component(props) {
    return (
        <section id='section5' className='section'>
            <h1>섹션5</h1>
        </section>
    );
}