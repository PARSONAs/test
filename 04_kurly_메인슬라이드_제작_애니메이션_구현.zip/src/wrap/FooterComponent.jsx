import React from 'react';

export  default function  FooterComponent () {
    return(
            <footer id='footer'>
                    <h2>푸터컴포넌트</h2>
            </footer>
    )
}
