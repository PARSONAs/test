import React from 'react';
import './scss/SubPublicComponent.scss';

export default function Sub2Component(props) {

    return (
        <div id='sub2' className='sub'>
            <h1>서브2 페이지</h1>
        </div>
    );
}