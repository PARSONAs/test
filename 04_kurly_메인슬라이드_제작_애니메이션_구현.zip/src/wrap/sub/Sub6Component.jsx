import React from 'react';
import './scss/SubPublicComponent.scss';

export default function Sub6Component(props) {
    return (
        <div id='sub6' className='sub'>
            <h1>서브6 페이지</h1>
        </div>
    );
}