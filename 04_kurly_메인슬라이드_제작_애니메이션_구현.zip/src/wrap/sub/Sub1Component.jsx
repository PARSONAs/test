import React from 'react';
import './scss/SubPublicComponent.scss';

export default function Sub1Component(props) {

    return (
        <div id='sub1' className='sub'>            
            <h1>서브1 페이지</h1>
        </div>
    );
}