import React from 'react';
import './scss/SubPublicComponent.scss';

export default function Sub5Component(props) {

    return (
        <div id='sub5' className='sub'>
            <h1>서브5 페이지</h1>
        </div>
    );
}