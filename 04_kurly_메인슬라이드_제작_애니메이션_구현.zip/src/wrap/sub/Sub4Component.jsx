import React from 'react';
import './scss/SubPublicComponent.scss';

export default function Sub4Component(props) {
    return (
        <div id='sub4' className='sub'>
            <h1>서브4 페이지</h1>
        </div>
    );
}