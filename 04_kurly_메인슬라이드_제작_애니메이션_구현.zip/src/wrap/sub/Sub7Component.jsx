import React from 'react';
import './scss/SubPublicComponent.scss';

export default function Sub7Component(props) {

    return (
        <div id='sub7' className='sub'>
            <h1>서브7 페이지</h1>
        </div>
    );
}