import React from 'react';
import './scss/SubPublicComponent.scss';

export default function None404Component(props) {

    return (
        <div id='none404' className='sub'>
            <h1>404 페이지</h1>
        </div>
    );
}